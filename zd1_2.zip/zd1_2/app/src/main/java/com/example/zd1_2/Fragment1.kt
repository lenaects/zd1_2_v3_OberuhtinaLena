package com.example.zd1_2

import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.navigation.fragment.NavHostFragment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [Fragment1.newInstance] factory method to
 * create an instance of this fragment.
 */
class Fragment1 : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }
    private lateinit var dateEditText: EditText
    private lateinit var amountEditText: EditText
    private lateinit var addButton: Button
    private lateinit var recyclerView: RecyclerView

    private val tasks = mutableListOf<ExpenseItem>()
    private lateinit var taskAdapter:TaskAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
         val binding = inflater.inflate(R.layout.fragment_1, container, false)
        dateEditText = binding.findViewById(R.id.editTextDate)
        amountEditText = binding.findViewById(R.id.editTextTask)
        addButton = binding.findViewById(R.id.buttonAddTask)
        recyclerView = binding.findViewById(R.id.listView)

        loadExpenseList()
        taskAdapter = TaskAdapter(tasks, this)
        recyclerView.adapter = taskAdapter
        recyclerView.layoutManager = LinearLayoutManager(activity)

        addButton.setOnClickListener {
            addExpense()
        }

        return binding
    }
    fun onExpenseItemClick(expenseItem: ExpenseItem) {
        // Обработка нажатия на элемент списка
        val bundle = Bundle()
        bundle.putString("date", expenseItem.date)
        bundle.putString("amount", expenseItem.amount)

        val navController = NavHostFragment.findNavController(this)
        navController.navigate(R.id.action_fragment1_to_fragment2, bundle)
    }
    private fun addExpense() {
        val date = dateEditText.text.toString()
        val amount = amountEditText.text.toString()

        if (date.isNotEmpty() && amount != null) {
            val expenseItem = ExpenseItem(date, amount)
            tasks.add(expenseItem)
            saveExpenseList()
            taskAdapter.notifyDataSetChanged()

            // Очищаем поля ввода
            dateEditText.text.clear()
            amountEditText.text.clear()
        } else {
            Toast.makeText(activity, "Введите корректные данные", Toast.LENGTH_SHORT).show()
        }

        loadExpenseList()
    }

    private fun saveExpenseList() {
        val gson = Gson()
        val json = gson.toJson(tasks)

        val preferences = activity?.getPreferences(Context.MODE_PRIVATE)
        preferences?.edit()?.putString("expenseList", json)?.apply()
    }
    private fun loadExpenseList() {
        val preferences = activity?.getPreferences(Context.MODE_PRIVATE)
        val json = preferences?.getString("expenseList", "")
        val type = object : TypeToken<List<ExpenseItem>>() {}.type

        tasks.clear()
        tasks.addAll(Gson().fromJson(json, type) ?: emptyList())

        // Убедимся, что адаптер и RecyclerView не null перед обновлением
        if (::taskAdapter.isInitialized && recyclerView.adapter != null) {
            taskAdapter.notifyDataSetChanged()
        }
    }
    companion object {

        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment Fragment1.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            Fragment1().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}