package com.example.zd1_2

data class ExpenseItem (
    val date: String,
    val amount: String,
    )