package com.example.zd1_2

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.NavigationView
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val host:NavHostFragment=supportFragmentManager
            .findFragmentById(R.id.navFragment)as NavHostFragment? ?:return
        val navController=host.navController
        val sideBar=findViewById<NavigationView>(R.id.nav_view)
        sideBar?.setupWithNavController(navController)

    }


}