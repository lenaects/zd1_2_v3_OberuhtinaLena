package com.example.zd1_2

import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.NavHostFragment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import android.widget.ArrayAdapter

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [Fragment2.newInstance] factory method to
 * create an instance of this fragment.
 */
class Fragment2 : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }
    private lateinit var textAllTxt: TextView
    private lateinit var spinnerImportance: Spinner
    private lateinit var amountEditText: EditText
    private lateinit var addButton: Button
    private lateinit var recyclerView:RecyclerView
    private val tasks = mutableListOf<ExpenseItem>()
    private lateinit var taskAdapter: TaskAdapterTwo
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        val binding = inflater.inflate(R.layout.fragment_2, container, false)

        textAllTxt = binding.findViewById(R.id.textView)


        val date = arguments?.getString("date", "") ?: ""
        val amount = arguments?.getString("amount", "") ?: ""
        textAllTxt.text = "Дата: "+ date + "\nНазвание:" + "$amount"

        spinnerImportance = binding.findViewById(R.id.spinnerImportance)
        amountEditText = binding.findViewById(R.id.editTextAmount)
        addButton = binding.findViewById(R.id.buttonSave)
        recyclerView = binding.findViewById(R.id.listView)
        val adapter = ArrayAdapter.createFromResource(
            requireContext(),
            R.array.importance_options,
            android.R.layout.simple_spinner_item
        )

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerImportance.adapter = adapter
        loadExpenseList()

        taskAdapter = TaskAdapterTwo(tasks)
        recyclerView.adapter = taskAdapter
        recyclerView.layoutManager = LinearLayoutManager(activity)

        addButton.setOnClickListener {
            addExpense()
        }

        return binding
    }
    fun onExpenseItemClick(expenseItem: ExpenseItem) {
        // Обработка нажатия на элемент списка
        val bundle = Bundle()
        bundle.putString("date", expenseItem.date)
        bundle.putString("amount", expenseItem.amount)

        val navController = NavHostFragment.findNavController(this)
        navController.navigate(R.id.action_fragment1_to_fragment2, bundle)
    }
    private fun addExpense() {
        val date = spinnerImportance.selectedItem.toString()
        val amount = amountEditText.text.toString()

        if (date.isNotEmpty() && amount != null) {
            val expenseItem = ExpenseItem(date, amount)
            tasks.add(expenseItem)
            saveExpenseList()
            taskAdapter.notifyDataSetChanged()

            // Очищаем поля ввода

            amountEditText.text.clear()
        } else {
            Toast.makeText(activity, "Введите корректные данные", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveExpenseList() {
        val gson = Gson()
        val json = gson.toJson(tasks)

        val preferences = activity?.getPreferences(Context.MODE_PRIVATE)
        preferences?.edit()?.putString("expenseList1", json)?.apply()
    }

    private fun loadExpenseList() {
        val preferences = activity?.getPreferences(Context.MODE_PRIVATE)
        val json = preferences?.getString("expenseList1", "")
        val type = object : TypeToken<List<ExpenseItem>>() {}.type

        tasks.clear()
        tasks.addAll(Gson().fromJson(json, type) ?: emptyList())
    }
    companion object {

        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment Fragment2.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            Fragment2().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}